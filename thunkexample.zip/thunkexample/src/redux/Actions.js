export const FETCH_USERS_REQUEST  ="fetch_request";
export const FETCH_USERS_SUCCESS  ="fetch_success";
export const FETCH_USERS_FAILURE  ="fetch_failure";
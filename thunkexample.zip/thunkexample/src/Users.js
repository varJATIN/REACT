import {fetchUsers} from './redux/thunkapi';
import {useSelector, useDispatch} from 'react-redux';
import React from 'react';

export default function Users() {
    //The selector is approximately equivalent to the mapStateToProps argument to connect conceptually. 
    const state = useSelector(state => state); 
    console.log(state);
    // mapDispatchToProps
    const dispatch = useDispatch();
    let {loading, error, users} = state;

    React.useEffect(() => {
        dispatch(fetchUsers());
    }, []);

    return <>
            {
                loading ? <h1> Loading....</h1> : users.map(user => {
                    return <h1 key={user.id}>{user.name}</h1>
                })
            }
    </>
}